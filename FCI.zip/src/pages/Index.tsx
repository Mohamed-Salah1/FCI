const Index = () => {
  return null; // App redirects from / to /login or /dashboard
};
export default Index;
